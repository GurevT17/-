﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gurev
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "gurevDataSet.Участники_выставки". При необходимости она может быть перемещена или удалена.
            this.участники_выставкиTableAdapter.Fill(this.gurevDataSet.Участники_выставки);

        }

        private void button6_Click(object sender, EventArgs e)
        {
            Form1 f1 = new Form1();
            f1.Owner = this;
            f1.ShowDialog();
            Form2 f2 = new Form2();
            f2.Owner = this;
            this.Close();
        }

        private void участники_выставкиBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.участники_выставкиBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.gurevDataSet);

        }

        private void bindingNavigatorMoveNextItem_Click(object sender, EventArgs e)
        {

        }

        private void участники_выставкиDataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
