﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gurev
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void клубBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.клубBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.gurevDataSet);

        }

        private void Form4_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "gurevDataSet.Клуб". При необходимости она может быть перемещена или удалена.
            this.клубTableAdapter.Fill(this.gurevDataSet.Клуб);

        }

        private void button6_Click(object sender, EventArgs e)
        {
            Form1 f1 = new Form1();
            f1.Owner = this;
            f1.ShowDialog();
            Form4 f4 = new Form4();
            f4.Owner = this;
            this.Close();
        }

        private void клубDataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
