﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gurev
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void button6_Click(object sender, EventArgs e)
        {

            Form1 f1 = new Form1();
            f1.Owner = this;
            f1.ShowDialog();
            Form3 f3 = new Form3();
            f3.Owner = this;
            this.Close();
        }

        private void экспертBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.экспертBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.gurevDataSet);

        }

        private void Form3_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "gurevDataSet.Эксперт". При необходимости она может быть перемещена или удалена.
            this.экспертTableAdapter.Fill(this.gurevDataSet.Эксперт);

        }
    }
}
