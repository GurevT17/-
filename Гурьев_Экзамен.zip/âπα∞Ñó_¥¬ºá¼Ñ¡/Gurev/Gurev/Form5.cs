﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gurev
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }

        private void рингBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.рингBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.gurevDataSet);

        }

        private void Form5_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "gurevDataSet.Ринг". При необходимости она может быть перемещена или удалена.
            this.рингTableAdapter.Fill(this.gurevDataSet.Ринг);

        }

        private void button6_Click(object sender, EventArgs e)
        {
            Form1 f1 = new Form1();
            f1.Owner = this;
            f1.ShowDialog();
            Form5 f5 = new Form5();
            f5.Owner = this;
            this.Close();
        }
    }
}
